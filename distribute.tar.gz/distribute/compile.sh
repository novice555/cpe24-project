gcc -ggdb -o distribute *.c split_file/*.c $1
