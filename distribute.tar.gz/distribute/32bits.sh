gcc -m32 -Wall -ggdb -o distribute_32bits *.c split_file/*.c
