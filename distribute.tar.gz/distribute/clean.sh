rm *.o
